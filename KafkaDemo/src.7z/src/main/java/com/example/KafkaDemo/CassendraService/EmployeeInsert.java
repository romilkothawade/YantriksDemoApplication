package com.example.KafkaDemo.CassendraService;

import com.example.KafkaDemo.model.Employee;
import org.springframework.data.cassandra.repository.CassandraRepository;

public interface EmployeeInsert extends CassandraRepository<Employee,Integer> {

}
