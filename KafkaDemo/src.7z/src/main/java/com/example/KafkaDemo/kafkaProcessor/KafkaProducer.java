package com.example.KafkaDemo.kafkaProcessor;


import com.example.KafkaDemo.model.CreateEmployeeResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class KafkaProducer {
    @Autowired
    KafkaTemplate<String, Object> kafkaTemplate;
    private static final String AppUpdateTopic = "app_updates";

    public void produceOnTopicAppUpdates(CreateEmployeeResponse message) {
        kafkaTemplate.send(AppUpdateTopic, message);
        log.info("message Produced on App Update Topic : " + message);
    }
}
