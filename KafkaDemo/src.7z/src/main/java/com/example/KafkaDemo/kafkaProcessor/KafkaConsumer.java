package com.example.KafkaDemo.kafkaProcessor;

public class KafkaConsumer {
}
