package com.example.KafkaDemo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FindSkillInput {
    Double java_exp;
    Double spring_exp;
}
